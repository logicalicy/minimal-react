import React from 'react';
import styled from 'styled-components';

const H1 = styled.h1`
  color: green;
`;

const App = () => (
  <H1>Hello world!</H1>
);

export default App;
