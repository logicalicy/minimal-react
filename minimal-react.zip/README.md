# Minimal React app

App made with:

* React
* Styled Components
* Webpack
* Webpack Dev Server
* HTML Webpack plugin
* Babel
